# Telegram + ChatGPT Bot

1. `.env` fayliga API kalitlarni kiriting
2. `pip install -r requirements.txt`
3. `python gpt_bot.py`
